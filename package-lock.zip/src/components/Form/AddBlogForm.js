import React, { useContext, useEffect, useState } from "react";
import Input from "../UI/Input";
import Button from "../UI/Button";
import "../UI/Input.css";
import Card from "../Card/Card";
import ErrorPopUp from "../UI/ErrorPopUp";
import AuthContext from "../auth-context";

const AddBlogForm = (props) => {
  const [title, setTitle] = useState("");
  const [image, setImage] = useState(null);
  const [description, setDescription] = useState("");
  const [author, setAuthor] = useState("");
  const [id, setId] = useState(null);
  const [errorPopUp, setErrorPopUp] = useState();

  const ctx = useContext(AuthContext);

  useEffect(() => {
    if (ctx.isEditData.title) {
      setTitle(ctx.isEditData.title);
      setImage(ctx.isEditData.image);
      setDescription(ctx.isEditData.description);
      setAuthor(ctx.isEditData.author);
      setId(ctx.isEditData.id);
    }
  }, [
    ctx.isEditData.title,
    ctx.isEditData.image,
    ctx.isEditData.description,
    ctx.isEditData.author,
    ctx.isEditData.id,
  ]);

  const formSubmitHandler = (event) => {
    event.preventDefault();

    if (title.trim().length === 0) {
      setErrorPopUp({
        message: "Please Enter Valid Title",
      });
      return;
    }

    if (image === null) {
      setErrorPopUp({
        message: "Please Select Image",
      });
      return;
    }

    if (description.trim().length === 0) {
      setErrorPopUp({
        message: "Please Enter Valid Description",
      });
      return;
    }

    if (author.trim().length === 0) {
      setErrorPopUp({
        message: "Please Enter Valid Author",
      });
      return;
    }

    props.fetchFormData(title, image, description, author, id);

    setTitle("");
    setImage(null);
    setDescription("");
    setAuthor("");
    setId(null);
  };

  const titleChangeHandler = (event) => {
    setTitle(event.target.value);
  };
  const imageChangeHandler = (event) => {
    if (event.target.files && event.target.files[0]) {
      setImage(URL.createObjectURL(event.target.files[0]));
    }
  };
  const descriptionChangeHandler = (event) => {
    setDescription(event.target.value);
  };
  const authorChangeHandler = (event) => {
    setAuthor(event.target.value);
  };

  const ErrorHandler = () => {
    setErrorPopUp(null);
  };
  return (
    <Card>
      <div className="text-center font-bold text-3xl pb-2">Blog Form</div>
      {errorPopUp && (
        <ErrorPopUp message={errorPopUp.message} onConfirm={ErrorHandler} />
      )}
      <form onSubmit={formSubmitHandler}>
        <Input
          type="text"
          name="title"
          id="title"
          label="Title"
          value={title}
          onChange={titleChangeHandler}
        />

        <Input
          type="file"
          name="image"
          id="image"
          label="Image"
          onChange={imageChangeHandler}
        />

        <div className="control">
          <label htmlFor="description">Description</label>
          <textarea
            className="border border-black h-[100px]"
            name="description"
            id="description"
            value={description}
            onChange={descriptionChangeHandler}
          />
        </div>
        <Input
          type="text"
          name="author"
          id="author"
          label="Author"
          value={author}
          onChange={authorChangeHandler}
        />
        {id && (
          <Button className="bg-green-600 hover:bg-green-700" type="submit">
            Edit Blog
          </Button>
        )}
        {!id && (
          <Button className="bg-blue-600 hover:bg-blue-700" type="submit">
            Add Blog
          </Button>
        )}
      </form>
    </Card>
  );
};

export default AddBlogForm;
