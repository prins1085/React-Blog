import React from "react";
import Card from "../Card/Card";
import Button from "./Button";
import "./ErrorPopUp.css";

const Backdrop = (props) => {
  return <div className="fixed top-0 left-0 w-full h-[100vh] backdrop" onClick={props.onConfirm} />;
};

const ModalOverlay = (props) => {
  return (
    <Card className="fixed top-[30vh] left-[10%] w-[80%]">
     
      <div className="p-[1rem] text-xl">
        <p>{props.message}</p>
      </div>
      <footer className="p-[1rem] flex justify-end">
        <Button className="bg-blue-700" onClick={props.onConfirm}>Okay</Button>
      </footer>
    </Card>
  );
};

const ErrorPopUp = (props) => {
  return (
    <React.Fragment>
      <Backdrop onConfirm={props.onConfirm}/>

      <ModalOverlay
        message={props.message}
        onConfirm={props.onConfirm}
        
      />
    </React.Fragment>
  );
};

export default ErrorPopUp;
