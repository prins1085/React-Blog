import React from "react";

const AuthContext = React.createContext({
    isEditData : "",
});

export default AuthContext;
